# Courier-Management
Software: XAMPP.   Programming  Language: PHP.  Front End: HTML, CSS.   Database Environment:  MySQL, phpMyAdmin.
